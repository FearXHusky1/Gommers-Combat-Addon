package net.minecraft.network.play;

import net.minecraft.network.INetHandler;
import net.minecraft.network.play.server.SPacketAdvancementInfo;
import net.minecraft.network.play.server.SPacketAnimation;
import net.minecraft.network.play.server.SPacketBlockAction;
import net.minecraft.network.play.server.SPacketBlockBreakAnim;
import net.minecraft.network.play.server.SPacketBlockChange;
import net.minecraft.network.play.server.SPacketCamera;
import net.minecraft.network.play.server.SPacketChangeGameState;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.network.play.server.SPacketChunkData;
import net.minecraft.network.play.server.SPacketCloseWindow;
import net.minecraft.network.play.server.SPacketCollectItem;
import net.minecraft.network.play.server.SPacketCombatEvent;
import net.minecraft.network.play.server.SPacketConfirmTransaction;
import net.minecraft.network.play.server.SPacketCooldown;
import net.minecraft.network.play.server.SPacketCustomPayload;
import net.minecraft.network.play.server.SPacketCustomSound;
import net.minecraft.network.play.server.SPacketDestroyEntities;
import net.minecraft.network.play.server.SPacketDisconnect;
import net.minecraft.network.play.server.SPacketDisplayObjective;
import net.minecraft.network.play.server.SPacketEffect;
import net.minecraft.network.play.server.SPacketEntity;
import net.minecraft.network.play.server.SPacketEntityAttach;
import net.minecraft.network.play.server.SPacketEntityEffect;
import net.minecraft.network.play.server.SPacketEntityEquipment;
import net.minecraft.network.play.server.SPacketEntityHeadLook;
import net.minecraft.network.play.server.SPacketEntityMetadata;
import net.minecraft.network.play.server.SPacketEntityProperties;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraft.network.play.server.SPacketEntityTeleport;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.network.play.server.SPacketExplosion;
import net.minecraft.network.play.server.SPacketHeldItemChange;
import net.minecraft.network.play.server.SPacketJoinGame;
import net.minecraft.network.play.server.SPacketKeepAlive;
import net.minecraft.network.play.server.SPacketMaps;
import net.minecraft.network.play.server.SPacketMoveVehicle;
import net.minecraft.network.play.server.SPacketMultiBlockChange;
import net.minecraft.network.play.server.SPacketOpenWindow;
import net.minecraft.network.play.server.SPacketParticles;
import net.minecraft.network.play.server.SPacketPlaceGhostRecipe;
import net.minecraft.network.play.server.SPacketPlayerAbilities;
import net.minecraft.network.play.server.SPacketPlayerListHeaderFooter;
import net.minecraft.network.play.server.SPacketPlayerListItem;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.network.play.server.SPacketRecipeBook;
import net.minecraft.network.play.server.SPacketRemoveEntityEffect;
import net.minecraft.network.play.server.SPacketResourcePackSend;
import net.minecraft.network.play.server.SPacketRespawn;
import net.minecraft.network.play.server.SPacketScoreboardObjective;
import net.minecraft.network.play.server.SPacketSelectAdvancementsTab;
import net.minecraft.network.play.server.SPacketServerDifficulty;
import net.minecraft.network.play.server.SPacketSetExperience;
import net.minecraft.network.play.server.SPacketSetPassengers;
import net.minecraft.network.play.server.SPacketSetSlot;
import net.minecraft.network.play.server.SPacketSignEditorOpen;
import net.minecraft.network.play.server.SPacketSoundEffect;
import net.minecraft.network.play.server.SPacketSpawnExperienceOrb;
import net.minecraft.network.play.server.SPacketSpawnGlobalEntity;
import net.minecraft.network.play.server.SPacketSpawnMob;
import net.minecraft.network.play.server.SPacketSpawnObject;
import net.minecraft.network.play.server.SPacketSpawnPainting;
import net.minecraft.network.play.server.SPacketSpawnPlayer;
import net.minecraft.network.play.server.SPacketSpawnPosition;
import net.minecraft.network.play.server.SPacketStatistics;
import net.minecraft.network.play.server.SPacketTabComplete;
import net.minecraft.network.play.server.SPacketTeams;
import net.minecraft.network.play.server.SPacketTimeUpdate;
import net.minecraft.network.play.server.SPacketTitle;
import net.minecraft.network.play.server.SPacketUnloadChunk;
import net.minecraft.network.play.server.SPacketUpdateBossInfo;
import net.minecraft.network.play.server.SPacketUpdateHealth;
import net.minecraft.network.play.server.SPacketUpdateScore;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.network.play.server.SPacketUseBed;
import net.minecraft.network.play.server.SPacketWindowItems;
import net.minecraft.network.play.server.SPacketWindowProperty;
import net.minecraft.network.play.server.SPacketWorldBorder;

public interface INetHandlerPlayClient extends INetHandler
{
    void func_147235_a(SPacketSpawnObject p_147235_1_);

    void func_147286_a(SPacketSpawnExperienceOrb p_147286_1_);

    void func_147292_a(SPacketSpawnGlobalEntity p_147292_1_);

    void func_147281_a(SPacketSpawnMob p_147281_1_);

    void func_147291_a(SPacketScoreboardObjective p_147291_1_);

    void func_147288_a(SPacketSpawnPainting p_147288_1_);

    void func_147237_a(SPacketSpawnPlayer p_147237_1_);

    void func_147279_a(SPacketAnimation p_147279_1_);

    void func_147293_a(SPacketStatistics p_147293_1_);

    void func_191980_a(SPacketRecipeBook p_191980_1_);

    void func_147294_a(SPacketBlockBreakAnim p_147294_1_);

    void func_147268_a(SPacketSignEditorOpen p_147268_1_);

    void func_147273_a(SPacketUpdateTileEntity p_147273_1_);

    void func_147261_a(SPacketBlockAction p_147261_1_);

    void func_147234_a(SPacketBlockChange p_147234_1_);

    void func_147251_a(SPacketChat p_147251_1_);

    void func_147274_a(SPacketTabComplete p_147274_1_);

    void func_147287_a(SPacketMultiBlockChange p_147287_1_);

    void func_147264_a(SPacketMaps p_147264_1_);

    void func_147239_a(SPacketConfirmTransaction p_147239_1_);

    void func_147276_a(SPacketCloseWindow p_147276_1_);

    void func_147241_a(SPacketWindowItems p_147241_1_);

    void func_147265_a(SPacketOpenWindow p_147265_1_);

    void func_147245_a(SPacketWindowProperty p_147245_1_);

    void func_147266_a(SPacketSetSlot p_147266_1_);

    void func_147240_a(SPacketCustomPayload p_147240_1_);

    void func_147253_a(SPacketDisconnect p_147253_1_);

    void func_147278_a(SPacketUseBed p_147278_1_);

    void func_147236_a(SPacketEntityStatus p_147236_1_);

    void func_147243_a(SPacketEntityAttach p_147243_1_);

    void func_184328_a(SPacketSetPassengers p_184328_1_);

    void func_147283_a(SPacketExplosion p_147283_1_);

    void func_147252_a(SPacketChangeGameState p_147252_1_);

    void func_147272_a(SPacketKeepAlive p_147272_1_);

    void func_147263_a(SPacketChunkData p_147263_1_);

    void func_184326_a(SPacketUnloadChunk p_184326_1_);

    void func_147277_a(SPacketEffect p_147277_1_);

    void func_147282_a(SPacketJoinGame p_147282_1_);

    void func_147259_a(SPacketEntity p_147259_1_);

    void func_184330_a(SPacketPlayerPosLook p_184330_1_);

    void func_147289_a(SPacketParticles p_147289_1_);

    void func_147270_a(SPacketPlayerAbilities p_147270_1_);

    void func_147256_a(SPacketPlayerListItem p_147256_1_);

    void func_147238_a(SPacketDestroyEntities p_147238_1_);

    void func_147262_a(SPacketRemoveEntityEffect p_147262_1_);

    void func_147280_a(SPacketRespawn p_147280_1_);

    void func_147267_a(SPacketEntityHeadLook p_147267_1_);

    void func_147257_a(SPacketHeldItemChange p_147257_1_);

    void func_147254_a(SPacketDisplayObjective p_147254_1_);

    void func_147284_a(SPacketEntityMetadata p_147284_1_);

    void func_147244_a(SPacketEntityVelocity p_147244_1_);

    void func_147242_a(SPacketEntityEquipment p_147242_1_);

    void func_147295_a(SPacketSetExperience p_147295_1_);

    void func_147249_a(SPacketUpdateHealth p_147249_1_);

    void func_147247_a(SPacketTeams p_147247_1_);

    void func_147250_a(SPacketUpdateScore p_147250_1_);

    void func_147271_a(SPacketSpawnPosition p_147271_1_);

    void func_147285_a(SPacketTimeUpdate p_147285_1_);

    void func_184327_a(SPacketSoundEffect p_184327_1_);

    void func_184329_a(SPacketCustomSound p_184329_1_);

    void func_147246_a(SPacketCollectItem p_147246_1_);

    void func_147275_a(SPacketEntityTeleport p_147275_1_);

    void func_147290_a(SPacketEntityProperties p_147290_1_);

    void func_147260_a(SPacketEntityEffect p_147260_1_);

    void func_175098_a(SPacketCombatEvent p_175098_1_);

    void func_175101_a(SPacketServerDifficulty p_175101_1_);

    void func_175094_a(SPacketCamera p_175094_1_);

    void func_175093_a(SPacketWorldBorder p_175093_1_);

    void func_175099_a(SPacketTitle p_175099_1_);

    void func_175096_a(SPacketPlayerListHeaderFooter p_175096_1_);

    void func_175095_a(SPacketResourcePackSend p_175095_1_);

    void func_184325_a(SPacketUpdateBossInfo p_184325_1_);

    void func_184324_a(SPacketCooldown p_184324_1_);

    void func_184323_a(SPacketMoveVehicle p_184323_1_);

    void func_191981_a(SPacketAdvancementInfo p_191981_1_);

    void func_194022_a(SPacketSelectAdvancementsTab p_194022_1_);

    void func_194307_a(SPacketPlaceGhostRecipe p_194307_1_);
}
