package net.minecraft.item;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class ItemShears extends Item
{
    public ItemShears()
    {
        this.func_77625_d(1);
        this.func_77656_e(238);
        this.func_77637_a(CreativeTabs.field_78040_i);
    }

    public boolean func_179218_a(ItemStack p_179218_1_, World p_179218_2_, IBlockState p_179218_3_, BlockPos p_179218_4_, EntityLivingBase p_179218_5_)
    {
        if (!p_179218_2_.field_72995_K)
        {
            p_179218_1_.func_77972_a(1, p_179218_5_);
        }

        Block block = p_179218_3_.func_177230_c();
        if (block instanceof net.minecraftforge.common.IShearable) return true;
        return p_179218_3_.func_185904_a() != Material.field_151584_j && block != Blocks.field_150321_G && block != Blocks.field_150329_H && block != Blocks.field_150395_bd && block != Blocks.field_150473_bD && block != Blocks.field_150325_L ? super.func_179218_a(p_179218_1_, p_179218_2_, p_179218_3_, p_179218_4_, p_179218_5_) : true;
    }

    public boolean func_150897_b(IBlockState p_150897_1_)
    {
        Block block = p_150897_1_.func_177230_c();
        return block == Blocks.field_150321_G || block == Blocks.field_150488_af || block == Blocks.field_150473_bD;
    }


    @Override
    public boolean func_111207_a(ItemStack itemstack, net.minecraft.entity.player.EntityPlayer player, EntityLivingBase entity, net.minecraft.util.EnumHand hand)
    {
        if (entity.field_70170_p.field_72995_K)
        {
            return false;
        }
        if (entity instanceof net.minecraftforge.common.IShearable)
        {
            net.minecraftforge.common.IShearable target = (net.minecraftforge.common.IShearable)entity;
            BlockPos pos = new BlockPos(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v);
            if (target.isShearable(itemstack, entity.field_70170_p, pos))
            {
                java.util.List<ItemStack> drops = target.onSheared(itemstack, entity.field_70170_p, pos,
                        net.minecraft.enchantment.EnchantmentHelper.func_77506_a(net.minecraft.init.Enchantments.field_185308_t, itemstack));

                java.util.Random rand = new java.util.Random();
                for(ItemStack stack : drops)
                {
                    net.minecraft.entity.item.EntityItem ent = entity.func_70099_a(stack, 1.0F);
                    ent.field_70181_x += rand.nextFloat() * 0.05F;
                    ent.field_70159_w += (rand.nextFloat() - rand.nextFloat()) * 0.1F;
                    ent.field_70179_y += (rand.nextFloat() - rand.nextFloat()) * 0.1F;
                }
                itemstack.func_77972_a(1, entity);
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean onBlockStartBreak(ItemStack itemstack, BlockPos pos, net.minecraft.entity.player.EntityPlayer player)
    {
        if (player.field_70170_p.field_72995_K || player.field_71075_bZ.field_75098_d)
        {
            return false;
        }
        Block block = player.field_70170_p.func_180495_p(pos).func_177230_c();
        if (block instanceof net.minecraftforge.common.IShearable)
        {
            net.minecraftforge.common.IShearable target = (net.minecraftforge.common.IShearable)block;
            if (target.isShearable(itemstack, player.field_70170_p, pos))
            {
                java.util.List<ItemStack> drops = target.onSheared(itemstack, player.field_70170_p, pos,
                        net.minecraft.enchantment.EnchantmentHelper.func_77506_a(net.minecraft.init.Enchantments.field_185308_t, itemstack));
                java.util.Random rand = new java.util.Random();

                for (ItemStack stack : drops)
                {
                    float f = 0.7F;
                    double d  = (double)(rand.nextFloat() * f) + (double)(1.0F - f) * 0.5D;
                    double d1 = (double)(rand.nextFloat() * f) + (double)(1.0F - f) * 0.5D;
                    double d2 = (double)(rand.nextFloat() * f) + (double)(1.0F - f) * 0.5D;
                    net.minecraft.entity.item.EntityItem entityitem = new net.minecraft.entity.item.EntityItem(player.field_70170_p, (double)pos.func_177958_n() + d, (double)pos.func_177956_o() + d1, (double)pos.func_177952_p() + d2, stack);
                    entityitem.func_174869_p();
                    player.field_70170_p.func_72838_d(entityitem);
                }

                itemstack.func_77972_a(1, player);
                player.func_71029_a(net.minecraft.stats.StatList.func_188055_a(block));
                player.field_70170_p.func_180501_a(pos, Blocks.field_150350_a.func_176223_P(), 11); //TODO: Move to IShearable implementors in 1.12+
                return true;
            }
        }
        return false;
    }

    public float func_150893_a(ItemStack p_150893_1_, IBlockState p_150893_2_)
    {
        Block block = p_150893_2_.func_177230_c();

        if (block != Blocks.field_150321_G && p_150893_2_.func_185904_a() != Material.field_151584_j)
        {
            return block == Blocks.field_150325_L ? 5.0F : super.func_150893_a(p_150893_1_, p_150893_2_);
        }
        else
        {
            return 15.0F;
        }
    }
}