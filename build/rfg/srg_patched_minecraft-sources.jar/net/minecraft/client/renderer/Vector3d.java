package net.minecraft.client.renderer;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class Vector3d
{
    public double field_181059_a;
    public double field_181060_b;
    public double field_181061_c;
}
