package net.minecraft.world.storage;

import net.minecraft.nbt.NBTTagCompound;

public abstract class WorldSavedData implements net.minecraftforge.common.util.INBTSerializable<NBTTagCompound>
{
    public final String field_76190_i;
    private boolean field_76189_a;

    public WorldSavedData(String p_i2141_1_)
    {
        this.field_76190_i = p_i2141_1_;
    }

    public abstract void func_76184_a(NBTTagCompound p_76184_1_);

    public abstract NBTTagCompound func_189551_b(NBTTagCompound p_189551_1_);

    public void func_76185_a()
    {
        this.func_76186_a(true);
    }

    public void func_76186_a(boolean p_76186_1_)
    {
        this.field_76189_a = p_76186_1_;
    }

    public boolean func_76188_b()
    {
        return this.field_76189_a;
    }

    public void deserializeNBT(NBTTagCompound nbt)
    {
        this.func_76184_a(nbt);
    }

    public NBTTagCompound serializeNBT()
    {
        return this.func_189551_b(new NBTTagCompound());
    }
}